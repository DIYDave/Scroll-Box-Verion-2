//
// Code for ESP8266 MCU. swissmade by dave@waldesbuehl.com 2017-2023
// Connect to a known WiFi and show QR-Code for the text input site. 
// If no known Wifi is found, AP mode will start an QR-Code for connection will show
// Act as Web Server or Client. Config in "Wifi_Matrix_OLED.h"
// Get a Textfile from Web server.
// Display various texts on the dot matrix display include the text from Web server.
// Display status information and QR-Code for de Web server path on the small OLED display.
// Upload sketch over USB or over the Air (OTA) (Needs installed Python 2.7x)
// If this code is useful for your own project, please send me a picture of your finished device :-)
// 
// Version 2.2 mit PacMan. works perfect

#include <Wifi_Matrix_OLED.h>       // <- Make your configuration here
 
// Define the number of 8x8 dot matrix devices and the hardware SPI interface
  #define HARDWARE_TYPE MD_MAX72XX::FC16_HW
  #define MAX_DEVICES 8
  #define CS_PIN  D6 
  
// build Instances
  WiFiManager wifiManager;
  MD_Parola Parola = MD_Parola(HARDWARE_TYPE, CS_PIN, MAX_DEVICES);  // HARDWARE SPI for dot matrix display
  U8G2_SH1106_128X64_VCOMH0_F_4W_SW_SPI u8g2(U8G2_R0, /* clock=*/ D1, /* data=*/ D2, /* cs=*/ D8, /* dc=*/ D4, /* reset=*/ D3);     // Software SPI for OLED !CS-pin unused (connected direct to ground on OLED)
  #ifdef IamTheServer
    ESP8266WebServer server(80);
  #else
    WiFiClient client;
  #endif
 

void setup() // ********************* Begin of Setup
{
  Serial.begin(57600);
  EEPROM.begin(150);   

  // Setup and start OLED display
  u8g2.begin();   
  u8g2.clearBuffer();          // clear the internal memory
  OLED_Screen1();              // Wellcome screen
  
  // Setup and start Dot matrix display
  Parola.begin(); 
  Parola.displayClear();
  Parola.displaySuspend(false);
  lumos = EEPROM.read(0);
  if (lumos == 0){    // if lumos not set yet
    lumos = 15;     
    Serial.println("0 from EEPROM!");
  }
  Parola.setIntensity(lumos);       // Values from 0 to 15      

  // Setup and start WiFi-Manager
  wifiManager.setAPCallback(configModeCallback);   // Call routine to show infos when in Config Mode
  wifiManager.autoConnect("ScrollText");          // Name of the buil-in accesspoint
  // Loop here until connection with Wifi
  OLED_Screen2();             // Connected Screen
  
  // Setup and start OTA service
  ArduinoOTA.begin();
   
  // Start animated text at first Run
  lastShowTime = millis() + showTimeInterval;

  #ifdef IamTheServer
    pathToServer = "http://"+ WiFi.localIP().toString();      // For QR-Code
    server.begin();
    server.on("/",handleWebsite);
    server.onNotFound (handleNotFound);
  #endif
}  // ******************************  End of Setup


void loop()   // ******************************  Start of loop
{
  ArduinoOTA.handle(); 

  if (Parola.displayAnimate()) // True if animation ended
  {
    switch (nStatus) {
      case 0:
        #ifndef IamTheServer 
        ConnectToServer();     // Get text from server
        #endif   
        Parola.displayText   ("Welcome", PA_CENTER, 25, 1200, PA_OPENING_CURSOR  , PA_OPENING_CURSOR );    
      break;
      case 1:
        Parola.displayText   ("to", PA_CENTER, 25, 1000, PA_OPENING_CURSOR  , PA_OPENING_CURSOR );
      break;    
      case 2:
          Parola.displayText("Dave's DIY", PA_CENTER, 30, 1000, PA_SPRITE, PA_SPRITE);
          Parola.setSpriteData(pacman1, W_PMAN1, F_PMAN1, pacman2, W_PMAN2, F_PMAN2);
      break; 
      case 3:
        if (millis() - lastShowTime > showTimeInterval) {
          Parola.displayText   ("electronic", PA_CENTER, 40, 1200, PA_SCROLL_UP_LEFT  , PA_SCROLL_UP_RIGHT  );
        }
      break; 
      case 4:
        createQR(pathToServer);   // Show QR-Code with path to the website
        if (millis() - lastShowTime > showTimeInterval) {
          Parola.displayText   ("tinkering", PA_CENTER, 50, 1200, PA_MESH  , PA_MESH );
        }
      break; 
      case 5:
        if (millis() - lastShowTime > showTimeInterval) {
          Parola.displayText   ("coding", PA_CENTER, 2, 100, PA_SLICE , PA_SLICE);
          lastShowTime = millis();
        }
      break; 
      case 6:                // Show server text
        Parola.displayScroll(curMessage, PA_LEFT, PA_SCROLL_LEFT, frameDelay); 
      break;     
      case 7:  
        Parola.displayScroll(curMessage, PA_LEFT, PA_SCROLL_LEFT, frameDelay); 
      break;     
      case 8:  
        lastStart = millis();
      break;    
    }
    if (nStatus <= 8){
        nStatus ++;
    }else if (millis()-lastStart > waitToStart){
        nStatus = 0;
    }
  }
  #ifdef IamTheServer
    server.handleClient();
  #endif
}   // ******************************  End of loop


#ifndef IamTheServer
  void ConnectToServer(){
    client.setTimeout(1000);                            // Start will delayed by this time (some how)
    const int httpPort = 80;
    if (!client.connect(host, httpPort)) {              // Use WiFiClient class to create TCP connection
      Serial.println("connection failed");
      return;
    }   
    client.print(String("GET ") + url + " HTTP/1.1\r\n" +     // Send request to the server
                "Host: " + host + "\r\n" + 
                "Connection: close\r\n\r\n");
    unsigned long timeout = millis();
    while (client.available() == 0) {
      if (millis() - timeout > 5000) {
        Serial.println(">>> Client Timeout !");
        client.stop();
        return;
      }
    }
    // Read all the lines of the reply from server
    while(client.available()){
      String line = client.readStringUntil('\r');
      // Serial.print(line);                           // Diag, Show's all the lines from HTTP answere
      if(line.endsWith("EOT")){                       // line with EOT at the end? (adding in PHP-Script to the end of text)
        line = line.substring(1,line.length() -3);    // Shortens the string by by 3 characters "EOT"
        if (line == "WiFiReset"){                      // Secret phrase to reset WiFi settings. Next start in config Mode
          wifiManager.resetSettings();
        }
        if(line.startsWith("Lumos=")){                    // Secret phrase to set intensity of dot matrix
          line = line.substring(6,line.length());
          SetIntensity(line);
          return;
        }
        line.toCharArray(curMessage, sizeof(curMessage));  
      }
    }
  }
#endif

#ifdef IamTheServer
  void handleWebsite(){
    if (server.hasArg("Scrolltext")) {
      String line = server.arg("Scrolltext");
      if (line == "WiFiReset"){                      // Secret phrase to reset WiFi settings. Next start in config Mode
        wifiManager.resetSettings();
      }else if(line.startsWith("Lumos=")){          // Secret phrase to set intensity of dot matrix                          
        line = line.substring(6,line.length());
        SetIntensity(line);
        return;
      }else {
        line.toCharArray(curMessage, sizeof(curMessage));
      }
    }
    server.send(200,"text/html",index_html);
  }
  void handleNotFound(){
    server.send(200,"text/html",Error404);
  }
#endif

void SetIntensity(String slumos ){           // Set the intensity of dot matrix. Text for Website: "Lumos=0" to "Lumos=15"
  long l = slumos.toInt();
  byte i = (byte) l;
  if ((i>=0) && (i<=15)){   // Values from 0 to 15
    if (i != lumos){        // Write only if changed
      lumos = i;
      EEPROM.write(0, i);       // Write the new value to EEPROM
      EEPROM.commit();
      Parola.setIntensity(i); 
    }
  } 
}
  
void configModeCallback (WiFiManager *myWiFiManager) {      // Show infos to log in with build in accesspoint. (Config Mode) When not possible to connect to WiFi 
  u8g2.clearBuffer();   u8g2.drawStr(0,11,"Config Mode");   
  u8g2.drawStr(0,27,"Scan QR, then go to "); 
  u8g2.drawStr(0,43,"IP address: ");    
  sprintf(oledTxt, "%03d.%03d.%03d.%03d", WiFi.softAPIP()[0], WiFi.softAPIP()[1], WiFi.softAPIP()[2], WiFi.softAPIP()[3]);
  u8g2.drawStr(0,59, oledTxt);  u8g2.sendBuffer(); 
  delay(4000);
  createQR(AP_Settings);          // Show QR code for AP 
}

void OLED_Screen1(){                        // Wellcome screen
  u8g2.clearDisplay();
  u8g2.clearBuffer(); 
  u8g2.setFont(u8g2_font_7x14B_tr);         // choose a small font for status dispay 
  u8g2.drawStr(0,11,"    Wellcome to"); 
  u8g2.setFont(u8g2_font_profont22_tf);  
  u8g2.drawStr(6,32, "ScrollText");  
  u8g2.setFont(u8g2_font_7x14B_tr); 
  u8g2.drawStr(0,48,"    Connecting.."); 
  u8g2.setFont(u8g2_font_6x10_tf); 
  u8g2.drawStr(0,64,"v2.2");  u8g2.sendBuffer(); 
}

void OLED_Screen2(){                      // Connected screen
  u8g2.clearDisplay();
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_7x14B_tr);       // choose a small font for status dispay 
  u8g2.drawStr(0,11,"WiFi connected");   
  u8g2.drawStr(0,27,"SSID: ");  
  WiFi.SSID().toCharArray(oledTxt, sizeof(oledTxt));
  u8g2.drawStr(37,27,oledTxt);  
  u8g2.drawStr(0,43,"IP address: ");    
  sprintf(oledTxt, "%03d.%03d.%03d.%03d", WiFi.localIP()[0], WiFi.localIP()[1], WiFi.localIP()[2], WiFi.localIP()[3]);
  u8g2.drawStr(0,59, oledTxt);  u8g2.sendBuffer();
}

void OLED_Screen3(){                        // Scan now screen
  u8g2.clearBuffer();
  u8g2.clearDisplay();
  u8g2.setDrawColor(1);
  u8g2.setFont(u8g2_font_profont22_tf);    // choose a big font for "Scan Now" text
  u8g2.drawStr(4,15,"QR scannen");   
  u8g2.drawStr(5,35,"-> eigener");   
  u8g2.drawStr(35,55,"Text!"); u8g2.sendBuffer();
}

void createQR(String message) {          //   // create & show QR-Code
  message.toCharArray((char *)strinbuf,260);
  qrencode();
  u8g2.clearDisplay();
  u8g2.clearBuffer();
  for (byte x = 0; x < WD; x+=2) {
    for (byte y = 0; y < WD; y++) {
      if ( QRBIT(x,y) &&  QRBIT((x+1),y)) {
        // black square on top of black square
        render(x, y, 1);
        render((x+1), y, 1);
      }
      if (!QRBIT(x,y) &&  QRBIT((x+1),y)) {
        // white square on top of black square
        render(x, y, 0);
        render((x+1), y, 1);
      }
      if ( QRBIT(x,y) && !QRBIT((x+1),y)) {
        // black square on top of white square
        render(x, y, 1);
        render((x+1), y, 0);
      }
      if (!QRBIT(x,y) && !QRBIT((x+1),y)) {
        // white square on top of white square
        render(x, y, 0);
        render((x+1), y, 0);
      }
    }
  }
  u8g2.sendBuffer();
}
    
void render(int x, int y, int color){
  multiply = 1;
  x=(x*multiply)+offsetsX;
  y=(y*multiply)+offsetsY;

  if(color==1) {
    u8g2.setDrawColor(1);
    u8g2.drawPixel(x, y);
  } else {
    u8g2.setDrawColor(0);
    u8g2.drawPixel(x, y);
  }
}
 