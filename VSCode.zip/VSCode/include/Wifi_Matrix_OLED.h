
// Version 2.2
//*******************************************************************************************************
#define IamTheServer          // Enabled: act as web server; Disabled: act als client and needs a server
//*******************************************************************************************************

// ESP Core 2.7.4 libraries
  #include <Arduino.h>
  #include <ESP8266WiFi.h>      // ESP library for all WiFi functions
  #include <DNSServer.h>        // used in AP mode (config mode) to connect direct to the web page 
  #include <ESP8266WebServer.h> // used in AP mode (config mode) and in Server mode
  #include <ArduinoOTA.h>       // Library for uploading sketch over the air (OTA)
  #include <SPI.h>              // Library for hardware or software driven SPI
  #include <EEPROM.h>           // Library for handle teh EEPROM

// Additional libraries
  #include <MD_Parola.h>        // v3.5.6 Parola library to scroll and display text on the display (needs MD_MAX72xx library)  https://github.com/MajicDesigns/MD_Parola
  #include <MD_MAX72xx.h>       // v3.3 Library to control the Maxim MAX7219 chip on the dot matrix module   https://github.com/MajicDesigns/MD_MAX72XX
  #include "U8g2lib.h"          // v2.28.11 Library to control the 128x64 Pixel OLED display with SH1106 chip  https://github.com/olikraus/u8g2
  #include <WiFiManager.h>      // v2.0.4-beta Manage auto connect to WiFi an fall back to AP   //https://github.com/tzapu/WiFiManager
  #include "qrbits.h"

  #ifdef IamTheServer
    String pathToServer;
  #else
    const String pathToServer  = "scrolltext.waldesbuehl.com";        // Path tho PHP script
    const char* host          = "scrolltext.waldesbuehl.com";         // Host URL
    const String url          = "/MeinText.txt";                      // Path to txt-file
  #endif

// Define global variables and const
  byte lumos;                                                       // Brightnes
  char oledTxt[25]      = "";
  uint8_t nStatus       = 0;
  
  char curMessage[100]   = "Welcome to Dave's DIY";                 // Message if no txt on server or new start in server mode
  const String AP_Settings  = "WIFI:S:ScrollText;T:nopass;;;";      // Wifi QR-Code in Config mode (S: SSID T:nopass - Keine Authentifikation) 

// LED Matrix
  const uint8_t frameDelay    = 25;                                 // default frame delay value
  unsigned long lastShowTime, showTimeInterval = 5 * 60 * 1000;     // Intervalltime to show the animated texts 5 Min.
  unsigned long lastStart, waitToStart = 2000;                      // Wait time for start of new cycle. (Blanc screen) 0..xxxxx[ms]
// OLED
  const int offsetsX = 42;
  const int offsetsY = 9;
  const int screenwidth = 128;
  const int screenheight = 64;
  bool QRDEBUG = false;
  int multiply = 1;

  extern unsigned char strinbuf[];
  extern unsigned char qrframe[];
  extern unsigned char  WD, WDB;

// Sprite Definitions
const uint8_t F_PMAN1 = 6;
const uint8_t W_PMAN1 = 8;
const uint8_t PROGMEM pacman1[F_PMAN1 * W_PMAN1] =    // gobbling pacman animation
{
  0x00, 0x81, 0xc3, 0xe7, 0xff, 0x7e, 0x7e, 0x3c,
  0x00, 0x42, 0xe7, 0xe7, 0xff, 0xff, 0x7e, 0x3c,
  0x24, 0x66, 0xe7, 0xff, 0xff, 0xff, 0x7e, 0x3c,
  0x3c, 0x7e, 0xff, 0xff, 0xff, 0xff, 0x7e, 0x3c,
  0x24, 0x66, 0xe7, 0xff, 0xff, 0xff, 0x7e, 0x3c,
  0x00, 0x42, 0xe7, 0xe7, 0xff, 0xff, 0x7e, 0x3c,
};

const uint8_t F_PMAN2 = 6;
const uint8_t W_PMAN2 = 18;
const uint8_t PROGMEM pacman2[F_PMAN2 * W_PMAN2] =    // ghost pursued by a pacman
{
  0x00, 0x81, 0xc3, 0xe7, 0xff, 0x7e, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
  0x00, 0x42, 0xe7, 0xe7, 0xff, 0xff, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
  0x24, 0x66, 0xe7, 0xff, 0xff, 0xff, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
  0x3c, 0x7e, 0xff, 0xff, 0xff, 0xff, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
  0x24, 0x66, 0xe7, 0xff, 0xff, 0xff, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
  0x00, 0x42, 0xe7, 0xe7, 0xff, 0xff, 0x7e, 0x3c, 0x00, 0x00, 0x00, 0xfe, 0x7b, 0xf3, 0x7f, 0xfb, 0x73, 0xfe,
};

  #ifdef IamTheServer
    void handleWebsite();
    void handleNotFound();
  #else
    void ConnectToServer();
  #endif
  void SetIntensity(String slumos );
  void configModeCallback(WiFiManager *myWiFiManager);
  void OLED_Screen1();
  void OLED_Screen2();
  void OLED_Screen3();
  void drawPic();
  void createQR(String message);
  void render(int x, int y, int color);


  #ifdef __cplusplus
  extern "C"{
  #endif
  // strinbuf in, qrframe out
  void qrencode(void);
  #ifdef __cplusplus
  } // extern "C"
  #endif


#ifdef IamTheServer
  const char index_html[] PROGMEM = R"=====(
  <!DOCTYPE html>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <style type="text/css">
  body {
      margin: 20px auto;
      background-color: LightGoldenRodYellow
      }
  </style>
  <Center>
  <font face='Arial,Helvetica'>
  <span style="font-size:16pt">
  <font color="blue">LED Laufschrift</font> <br>
  Geben sie hier den Text ein. (1 bis 100 Zeichen). 
  <br><br>
  <!-- Eingabefeldt und Sende-Button -->
  <FORM METHOD="post" action="/">
  <input type="text" size="60" name="Scrolltext" style="font-size:18pt" maxlength="120" required>
  <br>
  <br>
  <input type="submit" name="submit" value="Senden" style="font-size:16pt">
  </form>
  )=====";

  const char Error404[] PROGMEM = R"=====(
  <!DOCTYPE html>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <style type="text/css">
  body {
      margin: 20px auto;
      background-color: LightGoldenRodYellow
      }
  </style>
  <Center>
  <font face='Arial,Helvetica'>
  <span style="font-size:16pt">
  <font color="blue">LED Laufschrift</font> <br>
  Das gibt eine 404! Frag richtig du Opfer. 
  <br><br>
  <button onclick="goBack()" style="font-size:16pt">Go Back </button>

  <script>
  function goBack() {
    window.history.back();
  }
  </script>
  )=====";

#endif